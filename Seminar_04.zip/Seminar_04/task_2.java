package Seminar_04;

import java.util.LinkedList;
import java.util.Queue;

public class task_2 {

  public static void enqueue(Queue<Integer> array, int element) {
    array.offer(element);
  }

  public static int dequeue(Queue<Integer> array) {
    return array.poll();
  }

  public static int first(Queue<Integer> array) {
    return array.peek();
  }

  public static void main(String[] args) {
    // Реализуйте очередь с помощью LinkedList со следующими методами:
    // • enqueue() — помещает элемент в конец очереди,
    // • dequeue() — возвращает первый элемент из очереди и удаляет его,
    // • first() — возвращает первый элемент из очереди, не удаляя.
    Queue<Integer> queue = new LinkedList<Integer>();
    System.out.println("\nЗ А Д А Ч А  2\n");

    int len = 6;

    for (int i = 1; i < len; i++) {
      enqueue(queue, i);
      System.out.print("Добавляем элемент '" + i + "' -> " + queue + "\n");
    }

    for (int i = 0; i < len / 2; i++) {
      System.out.print("Возвращаем элемент из очереди '" +
          dequeue(queue) + "' и удаляем его -> " + queue + "\n");
    }

    System.out.print("Возвращаем элемент из очереди '" +
        first(queue) + "' - - - - - -----> " + queue + "\n\n");

  }
}
