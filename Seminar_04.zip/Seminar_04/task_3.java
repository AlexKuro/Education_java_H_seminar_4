package Seminar_04;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Scanner;
import java.io.IOException;
import java.util.logging.*;

public class task_3 {

  private static String mergStr(int a, String s, int b, int result) {
    String str = String.valueOf(a) + s + String.valueOf(b) + " = " + String.valueOf(result);
    return str;
  }

  private static String mergStrFl(float a, String s, float b, String t, float result) {
    String str = String.valueOf(a) + s + String.valueOf(b) + t + " = " + String.valueOf(result);
    return str;
  }

  public static void printarray(Deque<String> array) {
    int count = 1;
    for (String string : array) {
      System.out.println(count++ + ": " + string);
    }
  }

  public static void main(String[] args) throws SecurityException, IOException {

    // Реализовать простой калькулятор
    // + сделать журнал
    // В калькулятор добавьте возможность отменить последнюю операцию.
    System.out.print("\033[H\033[2J"); // очистка консоли

    System.out.println("\nЗ А Д А Ч А  3\n");
    System.out.println("- - ----------- К А Л Ь К У Л Я Т О Р ------------- - -");
    Deque<String> arhiv = new LinkedList<String>();

    boolean fl = true;
    Scanner iScanner = new Scanner(System.in);

    Logger logger = Logger.getLogger(task_3.class.getName());
    // ConsoleHandler ch = new ConsoleHandler(); // все ошибки в терминале
    FileHandler fh = new FileHandler("log_3.txt");
    // logger.addHandler(ch);
    logger.addHandler(fh);

    SimpleFormatter sFormat = new SimpleFormatter();
    // XMLFormatter xml = new XMLFormatter();
    fh.setFormatter(sFormat);
    // fh.setFormatter(xml);

    logger.setLevel(Level.CONFIG);
    logger.setUseParentHandlers(false);

    logger.info("Запуск программы 'КАЛЬКУЛЯТОР'.");

    do {
      System.out.println("\tСложение  - - - - - - - - - нажмите '1'");
      System.out.println("\tВычетание   - - - - - - - - нажмите '2'");
      System.out.println("\tУмножение   - - - - - - - - нажмите '3'");
      System.out.println("\tДеление   - - - - - - - - - нажмите '4'");
      System.out.println("\tПроцент - - - - - - - - - - нажмите '5'");
      System.out.println("\tОтмена последней операции - нажмите '6'");
      System.out.println("\tПечать архива операций  - - нажмите '7'");
      System.out.println("\tВыход из программы  - - - - нажмите '9'");

      // Выход из программы

      System.out.print("\nВведите число -> ");
      int n = iScanner.nextInt();
      int a, b;
      float r, t;
      switch (n) {
        case 1:
          System.out.print("- Сложение -\n");
          System.out.print("Введите первое число -> ");
          a = iScanner.nextInt();
          System.out.print("Введите второе число -> ");
          b = iScanner.nextInt();
          System.out.printf("\nСложение чисел: %d + %d = %d\n\n", a, b, a + b);
          logger.info("Сложение чисел: " + a + " + " + b + " = " + (a + b));
          arhiv.add(mergStr(a, " + ", b, a + b));
          break;
        case 2:
          System.out.print("- Вычетание -\n");
          System.out.print("Введите первое число -> ");
          a = iScanner.nextInt();
          System.out.print("Введите второе число -> ");
          b = iScanner.nextInt();
          System.out.printf("\nВычетание чисел: %d - %d = %d\n\n", a, b, a - b);
          logger.info("Вычетание чисел: " + a + " - " + b + " = " + (a - b));
          arhiv.add(mergStr(a, " - ", b, a - b));
          break;
        case 3:
          System.out.print("- Умножение -\n");
          System.out.print("Введите первое число -> ");
          a = iScanner.nextInt();
          System.out.print("Введите второе число -> ");
          b = iScanner.nextInt();
          System.out.printf("\nУмножение чисел: %d * %d = %d\n\n", a, b, a * b);
          logger.info("Умножение чисел: " + a + " * " + b + " = " + (a * b));
          arhiv.add(mergStr(a, " * ", b, a * b));
          break;
        case 4:
          System.out.print("- Деление -\n");
          System.out.print("Введите первое число -> ");
          r = iScanner.nextFloat();
          System.out.print("Введите второе число -> ");
          t = iScanner.nextFloat();
          System.out.printf("\nДеление чисел: %.1f / %.1f = %.2f\n\n", r, t, r / t);
          logger.info("Деление чисел: " + r + " / " + t + " = " + (r / t));
          arhiv.add(mergStrFl(r, " / ", t, "", r / t));
          break;
        case 5:
          System.out.print("- Процент -\n");
          System.out.print("Введите число -> ");
          r = iScanner.nextFloat();
          System.out.printf("Введите процент от числа %.0f -> ", r);
          t = iScanner.nextFloat();
          System.out.printf("\nПроцент от числа: %.0f - %.0f%% = %.0f\n\n", r, t, r * (100 - t) / 100);
          logger.info("Процент от числа: " + r + " - " + t + "%" + " = " + ((100 - t) / 100));
          arhiv.add(mergStrFl(r, " - ", t, "%", r * (100 - t) / 100));
          break;
        case 6:
          System.out.print("\n- Отмена последней операции -\n");
          System.out.print("Последняя операция -> " + arhiv.getLast() + "\n");
          System.out.println("Отменить последнию операцию?");
          String st = "";
          System.out.println("Да,  введите -> 'Y'");
          System.out.println("Нет, введите -> 'N'");
          System.out.print("Введите символ 'Y' или 'N' -> ");
          st = iScanner.next();
          if (st.toLowerCase().equals("y")) {
            System.out.print("Последняя операция -> " + arhiv.getLast() + " - отменена!" + "\n\n");
            logger.info("Последняя операция -> " + arhiv.getLast() + " - из архива удалена!");
            arhiv.pollLast();
          } else {
            System.out.print("Отмена действий, выход в главное меню!" + "\n\n");
          }
          break;
        case 7:
          System.out.print("\n- Печать архива операций -\n");
          printarray(arhiv);
          System.out.print("\n\n");
          logger.info("Печать архива: " + arhiv);
          break;
        case 9:
          System.out.print("Завершение программы 'КАЛЬКУЛЯТОР'.\n\n");
          fl = false;
          break;
      }
    } while (fl);
    logger.info("Завершение программы 'КАЛЬКУЛЯТОР'.");
    iScanner.close();
  }
}