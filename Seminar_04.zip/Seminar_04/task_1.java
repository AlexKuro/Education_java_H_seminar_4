package Seminar_04;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

public class task_1 {

  public static void fillarray(LinkedList<Integer> array, int size) {
    Random random = new Random();
    for (int i = 0; i < size; i++) {
      array.add(random.nextInt(99));
    }
  }

  public static void printarray(LinkedList<Integer> array) {
    Iterator<Integer> itar = array.iterator();
    while (itar.hasNext()) {
      System.out.print(itar.next() + " ");
    }
  }

  public static void mergeLinkedList(LinkedList<Integer> array, int size) {
    int left = 0;
    int right = 0;
    int k = size - 1;
    for (int i = 0; i < size / 2; i++) {
      left = array.get(i);
      right = array.get(k);
      array.set(i, right);
      array.set(k, left);
      k--;
    }
  }

  public static void main(String[] args) {
    // Пусть дан LinkedList с несколькими элементами.
    // Реализуйте метод, который вернёет «перевёрнутый» список.

    int size = 11;
    System.out.println("\nЗ А Д А Ч А  1\n");
    LinkedList<Integer> array = new LinkedList<>();
    fillarray(array, size);
    System.out.print("Массив заполнен - - ---> ");
    printarray(array);
    System.out.print("\n«Перевёрнутый» массив -> ");
    mergeLinkedList(array, size);
    printarray(array);
    System.out.print("\n\n");

  }
}
